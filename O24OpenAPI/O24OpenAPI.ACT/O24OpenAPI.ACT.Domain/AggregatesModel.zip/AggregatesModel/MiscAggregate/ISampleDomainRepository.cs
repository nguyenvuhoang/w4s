using O24OpenAPI.Core.SeedWork;

namespace O24OpenAPI.ACT.Domain.AggregatesModel.MiscAggregate;

public interface ISampleDomainRepository : IRepository<SampleDomain>
{}
