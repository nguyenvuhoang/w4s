using O24OpenAPI.Core.Domain;

namespace O24OpenAPI.ACT.Domain.AggregatesModel.MiscAggregate;

public partial class SampleDomain : BaseEntity { }
