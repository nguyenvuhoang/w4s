using O24OpenAPI.Core.SeedWork;
using O24OpenAPI.ACT.Domain;

namespace O24OpenAPI.ACT.Domain.AggregatesModel.AccountAggregate;

public interface IAccountChartRepository : IRepository<AccountChart>
{
    Task<AccountChart?> GetByAccountNumberAsync(string accountNumber);
    Task<IReadOnlyList<AccountChart>> GetByBranchCodeCurrencyCodeAsync(string branchCode, string currencyCode);
}
