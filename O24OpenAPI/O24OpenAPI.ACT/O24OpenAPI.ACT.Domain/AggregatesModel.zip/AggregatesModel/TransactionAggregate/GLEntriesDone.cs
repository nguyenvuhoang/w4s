﻿using O24OpenAPI.Framework.Domain;

namespace O24OpenAPI.ACT.Domain.AggregatesModel.TransactionAggregate;

public partial class GLEntriesDone : GLEntries { }
