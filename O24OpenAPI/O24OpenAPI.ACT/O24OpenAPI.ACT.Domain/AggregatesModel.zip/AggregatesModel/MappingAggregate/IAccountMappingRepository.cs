using O24OpenAPI.Core.SeedWork;

namespace O24OpenAPI.ACT.Domain.AggregatesModel.MappingAggregate;

public interface IAccountMappingRepository : IRepository<AccountMapping>
{}
