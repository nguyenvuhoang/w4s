using O24OpenAPI.Core.SeedWork;

namespace O24OpenAPI.ACT.Domain.AggregatesModel.MappingAggregate;

public interface IAccountMappingDetailRepository : IRepository<AccountMappingDetail>
{}
