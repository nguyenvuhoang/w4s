using LinKit.Core.Abstractions;
using LinqToDB;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Core.Caching;
using O24OpenAPI.Core.Events;
using O24OpenAPI.Data;
using O24OpenAPI.CTH.Domain.AggregatesModel.TransactionAggregate;

using System;
using O24OpenAPI.Data.System.Linq;
namespace O24OpenAPI.CTH.Infrastructure.Repositories;

[RegisterService(Lifetime.Scoped)]
public class TransactionDefinitionRepository(
    IEventPublisher eventPublisher,
    IO24OpenAPIDataProvider dataProvider,
    IStaticCacheManager staticCacheManager
)
    : EntityRepository<TransactionDefinition>(eventPublisher, dataProvider, staticCacheManager),
        ITransactionDefinitionRepository
{

private static readonly StringComparison ICIC = StringComparison.InvariantCultureIgnoreCase;

public async Task<List<TransactionDefinition>> GetAllAsync()
{
    return await Table.ToListAsync();
}

public async Task<TransactionDefinition?> GetByTransactionCodeAsync(string transactionCode)
{
    return await Table.Where(t => t.TransactionCode == transactionCode).FirstOrDefaultAsync();
}

public async Task<TransactionDefinition> SearchAsync(O24OpenAPI.Framework.Models.SimpleSearchModel model)
{
    model.PageSize = model.PageSize == 0 ? int.MaxValue : model.PageSize;
    model.SearchText ??= string.Empty;

    var query = Table.Where(c =>
        c.TransactionCode.Contains(model.SearchText, ICIC)
        || c.WorkflowId.Contains(model.SearchText, ICIC)
        || c.TransactionName.Contains(model.SearchText, ICIC)
        || c.Description.Contains(model.SearchText, ICIC)
        || c.TransactionType.Contains(model.SearchText, ICIC)
        || c.ServiceId.Contains(model.SearchText, ICIC)
        || c.MessageAccount.Contains(model.SearchText, ICIC)
        || c.MessageAmount.Contains(model.SearchText, ICIC)
        || c.MessageCurrency.Contains(model.SearchText, ICIC)
        || c.Voucher.Contains(model.SearchText, ICIC)
        || c.ApplicationCode.Contains(model.SearchText, ICIC)
        || c.TransactionModel.Contains(model.SearchText, ICIC)
        || c.Channel.Contains(model.SearchText, ICIC)
    );

    return (TransactionDefinition)await query.ToPagedList(model.PageIndex, model.PageSize);
}
}
