using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Core.SeedWork;
using System;
using O24OpenAPI.Data.System.Linq;

namespace O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate
{
    public interface IUserAvatarRepository : IRepository<UserAvatar>
    {
        Task<UserAvatar> GetByUserCodeAsync(string request);
        Task UpdateAsync(UserAccount entity);

    }
}
