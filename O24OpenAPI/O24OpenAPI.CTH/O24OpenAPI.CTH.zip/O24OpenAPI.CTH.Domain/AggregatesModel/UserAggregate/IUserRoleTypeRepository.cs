﻿using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Core.SeedWork;
using O24OpenAPI.CTH.Domain.AggregatesModel.SampleAggregate;
using System;
using System.Collections.Generic;
using System.Text;

namespace O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate
{
    public interface IUserRoleTypeRepository : IRepository<RoleType>
    {

    }
}
