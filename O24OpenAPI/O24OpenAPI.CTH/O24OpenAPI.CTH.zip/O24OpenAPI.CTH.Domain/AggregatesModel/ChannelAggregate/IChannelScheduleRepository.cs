using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Core.SeedWork;

namespace O24OpenAPI.CTH.Domain.AggregatesModel.ChannelAggregate
{
    public interface IChannelScheduleRepository : IRepository<ChannelSchedule>
    {
    }
}
