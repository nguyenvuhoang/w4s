﻿using O24OpenAPI.Core.Domain;

namespace O24OpenAPI.CTH.Domain.AggregatesModel.SampleAggregate;

public class Sample : BaseEntity { }
