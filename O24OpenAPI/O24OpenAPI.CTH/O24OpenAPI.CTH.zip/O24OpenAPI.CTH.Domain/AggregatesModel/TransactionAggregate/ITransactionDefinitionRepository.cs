using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Core.SeedWork;

namespace O24OpenAPI.CTH.Domain.AggregatesModel.TransactionAggregate
{
    public interface ITransactionDefinitionRepository : IRepository<TransactionDefinition>
    {
    }
}
