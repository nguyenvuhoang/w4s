﻿namespace O24OpenAPI.CTH.API.Application.Abstractions;

public interface IQdrantService
{
}
