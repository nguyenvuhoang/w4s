using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.TransactionAggregate;

namespace O24OpenAPI.CTH.API.Features.Transaction
{
    public class InsertTranDefCommnad: BaseTransactionModel, ICommand<TransactionDefinition>
    {

    }

    public class InsertTranDefHandler(ITransactionDefinitionRepository transactionDefinitionRepository) : ICommandHandler<InsertTranDefCommnad, TransactionDefinition>
    {
        public async Task<TransactionDefinition> HandleAsync(InsertTranDefCommnad request, CancellationToken cancellationToken = default)
        {
        await transactionDefinitionRepository.Insert(transactionDefinition);
            return transactionDefinition;
        }
    }
}
