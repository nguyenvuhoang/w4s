using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.TransactionAggregate;

namespace O24OpenAPI.CTH.API.Features.Transaction
{
    public class GetByIdCommnad: BaseTransactionModel, ICommand<TransactionDefinition>
    {

    }

    public class GetByIdHandler(ITransactionDefinitionRepository transactionDefinitionRepository) : ICommandHandler<GetByIdCommnad, TransactionDefinition>
    {
        public async Task<TransactionDefinition> HandleAsync(GetByIdCommnad request, CancellationToken cancellationToken = default)
        {
        return await transactionDefinitionRepository.GetById(
                transactionDefinitionId,
                cache => default
            );
        }
    }
}
