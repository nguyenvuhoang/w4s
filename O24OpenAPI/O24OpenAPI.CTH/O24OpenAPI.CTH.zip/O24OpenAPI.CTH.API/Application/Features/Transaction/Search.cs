using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.TransactionAggregate;

namespace O24OpenAPI.CTH.API.Features.Transaction
{
    public class SearchCommnad: BaseTransactionModel, ICommand<IPagedList<TransactionDefinition>>
    {

    }

    public class SearchHandler(ITransactionDefinitionRepository transactionDefinitionRepository) : ICommandHandler<SearchCommnad, IPagedList<TransactionDefinition>>
    {
        public async Task<IPagedList<TransactionDefinition>> HandleAsync(SearchCommnad request, CancellationToken cancellationToken = default)
        {
        model.PageSize = model.PageSize == 0 ? int.MaxValue : model.PageSize;
            if (model.SearchText == null)
            {
                model.SearchText = string.Empty;
            }

            var TransDefs = transactionDefinitionRepository.Table.Where(c =>
                c.TransactionCode.Contains(model.SearchText, ICIC)
                || c.WorkflowId.Contains(model.SearchText, ICIC)
                || c.TransactionName.Contains(model.SearchText, ICIC)
                || c.Description.Contains(model.SearchText, ICIC)
                || c.TransactionType.Contains(model.SearchText, ICIC)
                || c.ServiceId.Contains(model.SearchText, ICIC)
                || c.MessageAccount.Contains(model.SearchText, ICIC)
                || c.MessageAmount.Contains(model.SearchText, ICIC)
                || c.MessageCurrency.Contains(model.SearchText, ICIC)
                || c.Voucher.Contains(model.SearchText, ICIC)
                || c.ApplicationCode.Contains(model.SearchText, ICIC)
                || c.TransactionModel.Contains(model.SearchText, ICIC)
                || c.Channel.Contains(model.SearchText, ICIC)
            );
            var PaegeTransDefs = await TransDefs.ToPagedList(model.PageIndex, model.PageSize);
            return PaegeTransDefs;
        }
    }
}
