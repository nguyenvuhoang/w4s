using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.TransactionAggregate;

namespace O24OpenAPI.CTH.API.Features.Transaction
{
    public class GetAllCommnad: BaseTransactionModel, ICommand<IList<TransactionDefinition>>
    {

    }

    public class GetAllHandler(ITransactionDefinitionRepository transactionDefinitionRepository) : ICommandHandler<GetAllCommnad, IList<TransactionDefinition>>
    {
        public async Task<IList<TransactionDefinition>> HandleAsync(GetAllCommnad request, CancellationToken cancellationToken = default)
        {
        var transactionDefinitions = await transactionDefinitionRepository.GetAll(query =>
            {
                return query;
            });

            return transactionDefinitions;
        }
    }
}
