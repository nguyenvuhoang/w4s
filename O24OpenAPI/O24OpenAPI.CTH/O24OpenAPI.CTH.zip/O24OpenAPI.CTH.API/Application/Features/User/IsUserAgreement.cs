using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class IsUserAgreementCommnad: BaseTransactionModel, ICommand<bool>
    {

    }

    public class IsUserAgreementHandler(IUserAgreementRepository userAgreementRepository) : ICommandHandler<IsUserAgreementCommnad, bool>
    {
        public async Task<bool> HandleAsync(IsUserAgreementCommnad request, CancellationToken cancellationToken = default)
        {
        var isAgreement = await userAgreementRepository
                .Table.Where(ua => ua.TransactionCode.Contains(commandid) && ua.IsActive)
                .FirstOrDefaultAsync();
            if (isAgreement != null)
            {
                return true;
            }
            return false;
        }
    }
}
