using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class GetNextRoleIdCommnad: BaseTransactionModel, ICommand<int>
    {

    }

    public class GetNextRoleIdHandler(IUserRoleRepository userRoleRepository) : ICommandHandler<GetNextRoleIdCommnad, int>
    {
        public async Task<int> HandleAsync(GetNextRoleIdCommnad request, CancellationToken cancellationToken = default)
        {
        var maxId = await userRoleRepository.Table
                .Select(x => (int?)x.RoleId)
                .MaxAsync();

            return (maxId ?? 0) + 1;
        }
    }
}
