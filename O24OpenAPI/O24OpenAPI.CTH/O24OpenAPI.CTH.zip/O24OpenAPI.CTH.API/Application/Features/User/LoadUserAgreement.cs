using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Models;
using O24OpenAPI.CTH.Models.Roles;
using O24OpenAPI.CTH.Models.User;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class LoadUserAgreementCommnad: BaseTransactionModel, ICommand<UserAgreement>
    {
        public new string TransactionCode { get; set; }
    }

    public class LoadUserAgreementHandler(IUserAgreementRepository userAgreementRepository) : ICommandHandler<LoadUserAgreementCommnad, UserAgreement>
    {
        public async Task<UserAgreement> HandleAsync(LoadUserAgreementCommnad request, CancellationToken cancellationToken = default)
        {
        return await userAgreementRepository.Table
                .Where(s => s.IsActive && s.TransactionCode == request.TransactionCode)
                .FirstOrDefaultAsync();
        }
    }
}
