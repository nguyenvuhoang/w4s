using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Models;
using O24OpenAPI.CTH.Models.Roles;
using O24OpenAPI.CTH.Models.User;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class UpdateListUserLimitCommnad: BaseTransactionModel, ICommand<virtual Task<List<UserLimitUpdateResponseModel>>>
    {
        public List<UserLimitUpdateResponseModel> ListUserLimit { get; set; }
    }

    public class UpdateListUserLimitHandler(IUserLimitRepository userLimitRepository) : ICommandHandler<UpdateListUserLimitCommnad, virtual Task<List<UserLimitUpdateResponseModel>>>
    {
        public async Task<virtual Task<List<UserLimitUpdateResponseModel>>> HandleAsync(UpdateListUserLimitCommnad request, CancellationToken cancellationToken = default)
        {
        UserLimit checkUserLimit;
            var respone = new List<UserLimitUpdateResponseModel>();

            foreach (var item in request.ListUserLimit)
            {
                checkUserLimit = await GetUserLimitToUpdate(item);

                if (checkUserLimit != null)
                {
                    checkUserLimit.ULimit = item.ULimit;
                    await userLimitRepository.Update(checkUserLimit);
                }
                else
                {
                    checkUserLimit = new UserLimit()
                    {
                        RoleId = item.RoleId,
                        CommandId = item.CommandId,
                        CurrencyCode = item.CurrencyCode,
                        ULimit = item.ULimit,
                        CvTable = string.Empty,
                        LimitType = item.LimitType,
                        Margin = 0,
                    };
                    await userLimitRepository.InsertAsync(checkUserLimit);
                }
                respone.Add(
                    new UserLimitUpdateResponseModel()
                    {
                        RoleId = checkUserLimit.RoleId,
                        CommandId = checkUserLimit.CommandId,
                        CurrencyCode = checkUserLimit.CurrencyCode,
                        ULimit = checkUserLimit.ULimit,
                        LimitType = checkUserLimit.LimitType,
                    }
                );
            }
            return respone;
        }
    }
}
