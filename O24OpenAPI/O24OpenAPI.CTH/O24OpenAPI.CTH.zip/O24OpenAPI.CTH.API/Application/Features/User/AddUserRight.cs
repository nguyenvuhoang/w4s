using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class AddUserRightCommnad: BaseTransactionModel, ICommand<UserRight>
    {

    }

    public class AddUserRightHandler(IUserRightRepository userRightRepository) : ICommandHandler<AddUserRightCommnad, UserRight>
    {
        public async Task<UserRight> HandleAsync(AddUserRightCommnad request, CancellationToken cancellationToken = default)
        {
        return await userRightRepository.InsertAsync(entity);
        }
    }
}
