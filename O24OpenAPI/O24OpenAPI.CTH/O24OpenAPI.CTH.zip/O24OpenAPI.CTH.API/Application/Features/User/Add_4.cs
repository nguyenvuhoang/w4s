using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class AddCommnad: BaseTransactionModel, ICommand<UserInRole>
    {

    }

    public class AddHandler(IUserInRoleRepository userInRoleRepository) : ICommandHandler<AddCommnad, UserInRole>
    {
        public async Task<UserInRole> HandleAsync(AddCommnad request, CancellationToken cancellationToken = default)
        {
        return await userInRoleRepository.InsertAsync(userInRole);
        }
    }
}
