using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class AddCommnad: BaseTransactionModel, ICommand<UserDevice>
    {

    }

    public class AddHandler(IUserDeviceRepository userDeviceRepository) : ICommandHandler<AddCommnad, UserDevice>
    {
        public async Task<UserDevice> HandleAsync(AddCommnad request, CancellationToken cancellationToken = default)
        {
        return await userDeviceRepository.InsertAsync(entity);
        }
    }
}
