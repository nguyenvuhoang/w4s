using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class GetByUserCodeCommnad: BaseTransactionModel, ICommand<virtual Task<UserDevice>>
    {

    }

    public class GetByUserCodeHandler(IUserDeviceRepository userDeviceRepository) : ICommandHandler<GetByUserCodeCommnad, virtual Task<UserDevice>>
    {
        public async Task<virtual Task<UserDevice>> HandleAsync(GetByUserCodeCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrWhiteSpace(userCode))
            {
                return null;
            }

            try
            {
                var query = userDeviceRepository.Table;
                return query == null
                    ? throw new InvalidOperationException("UserDevice repository table is null.")
                    : await query
                        .Where(d => d.UserCode == userCode && d.Status == Code.ShowStatus.ACTIVE)
                        .FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                await ex.LogErrorAsync();
                throw;
            }
        }
    }
}
