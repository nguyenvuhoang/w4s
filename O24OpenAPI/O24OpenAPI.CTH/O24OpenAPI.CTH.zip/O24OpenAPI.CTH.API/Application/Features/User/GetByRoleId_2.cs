using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class GetByRoleIdCommnad: BaseTransactionModel, ICommand<UserRole>
    {

    }

    public class GetByRoleIdHandler(IUserRoleRepository userRoleRepository) : ICommandHandler<GetByRoleIdCommnad, UserRole>
    {
        public async Task<UserRole> HandleAsync(GetByRoleIdCommnad request, CancellationToken cancellationToken = default)
        {
        return await userRoleRepository.Table.Where(s => s.RoleId == roleId).FirstOrDefaultAsync();
        }
    }
}
