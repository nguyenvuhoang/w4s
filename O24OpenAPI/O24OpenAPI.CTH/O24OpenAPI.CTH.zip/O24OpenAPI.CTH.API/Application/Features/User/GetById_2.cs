using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class GetByIdCommnad: BaseTransactionModel, ICommand<virtual Task<UserLimit>>
    {

    }

    public class GetByIdHandler(IUserLimitRepository userLimitRepository) : ICommandHandler<GetByIdCommnad, virtual Task<UserLimit>>
    {
        public async Task<virtual Task<UserLimit>> HandleAsync(GetByIdCommnad request, CancellationToken cancellationToken = default)
        {
        return await userLimitRepository.GetById(id, cache => default);
        }
    }
}
