using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Models;
using O24OpenAPI.CTH.Models.Roles;
using O24OpenAPI.CTH.Models.User;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class SearchCommnad: BaseTransactionModel, ICommand<virtual Task<IPagedList<UserLimitAdvancedSearchResponseModel>>>
    {
        public int? RoleId { get; set; }
        public string CommandId { get; set; }
        public string LimitType { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }

    public class SearchHandler(IUserLimitRepository userLimitRepository, IUserCommandRepository userCommandRepository) : ICommandHandler<SearchCommnad, virtual Task<IPagedList<UserLimitAdvancedSearchResponseModel>>>
    {
        public async Task<virtual Task<IPagedList<UserLimitAdvancedSearchResponseModel>>> HandleAsync(SearchCommnad request, CancellationToken cancellationToken = default)
        {
        request.PageSize = request.PageSize == 0 ? int.MaxValue : request.PageSize;

            var uLimit = userLimitRepository.Table;
            if (request.RoleId != null)
            {
                uLimit = uLimit.Where(x => x.RoleId == request.RoleId);
            }

            if (request.CommandId != null)
            {
                uLimit = uLimit.Where(x => x.CommandId.Contains(request.CommandId, ICIC));
            }

            if (request.LimitType.HasValue())
            {
                uLimit = uLimit.Where(x => x.LimitType.Equals(request.LimitType));
            }

            uLimit.OrderBy(o => o.Id);

            var result = await (
                from a in uLimit
                join userCommand1 in userCommandRepository.Table.Where(s =>
                    s.CommandType == "T" && s.Enabled == true
                )
                    on a.CommandId equals userCommand1.CommandId
                    into j1
                from b in j1 //.DefaultIfEmpty()
                join userCommand2 in userCommandRepository.Table.Where(s =>
                    s.CommandType == "T" && s.Enabled == true
                )
                    on b.ParentId equals userCommand2.CommandId
                    into j2
                from c in j2.DefaultIfEmpty()
                select new UserLimitAdvancedSearchResponseModel()
                {
                    Id = a.Id,
                    RoleId = a.RoleId,
                    CommandId = a.CommandId,
                    CurrencyCode = a.CurrencyCode,
                    ULimit = a.ULimit,
                    CvTable = a.CvTable,
                    LimitType = a.LimitType,
                    Margin = a.Margin,
                    Module = c.CommandName,
                    TranName = b.CommandName,
                }
            ).OrderBy(o => o.Module).ThenBy(o => o.TranName).ToPagedList(request.PageIndex, request.PageSize);
            return result;
        }
    }
}
