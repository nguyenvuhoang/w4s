using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class UpdateUserAvatarCommnad: BaseTransactionModel, ICommand<bool>
    {
        public string UserCode { get; set; }
        public string AvatarUrl { get; set; }
        public DateTime DateInsert { get; set; }
    }

    public class UpdateUserAvatarHandler(IUserAvatarRepository userAvatarRepository) : ICommandHandler<UpdateUserAvatarCommnad, bool>
    {
        public async Task<bool> HandleAsync(UpdateUserAvatarCommnad request, CancellationToken cancellationToken = default)
        {
        try
            {
                var entity = await userAvatarRepository.GetByUserCodeAsync(request.UserCode);

                if (entity == null)
                {
                    entity = new UserAvatar
                    {
                        UserCode = request.UserCode,
                        ImageUrl = request.AvatarUrl,
                        DateInsert = DateTime.UtcNow,
                    };

                    await userAvatarRepository.InsertAsync(entity);
                }
                else
                {
                    entity.ImageUrl = request.AvatarUrl;
                    await userAvatarRepository.UpdateAsync(entity);
                }

                return true;
            }
            catch (O24Exception)
            {
                throw;
            }
            catch (Exception ex)
            {
                await ex.LogErrorAsync(
                    $"[UpdateUserAvatarAsync] Error for {request.UserCode}: {ex.Message}"
                );
                throw await O24Exception.CreateAsync(
                    ResourceCode.Common.SystemError,
                    request.Language,
                    ex
                );
            }
        }
    }
}
