using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class BulkInsertCommnad: BaseTransactionModel, ICommand<List<UserInRole>>
    {

    }

    public class BulkInsertHandler(IUserInRoleRepository userInRoleRepository) : ICommandHandler<BulkInsertCommnad, List<UserInRole>>
    {
        public async Task<List<UserInRole>> HandleAsync(BulkInsertCommnad request, CancellationToken cancellationToken = default)
        {
        await userInRoleRepository.BulkInsert(userInRole);
            return userInRole;
        }
    }
}
