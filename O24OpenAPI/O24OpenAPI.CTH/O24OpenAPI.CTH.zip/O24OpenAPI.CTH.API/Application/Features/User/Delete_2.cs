using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.User
{
    public class DeleteCommnad: BaseTransactionModel, ICommand<virtual Task>
    {

    }

    public class DeleteHandler(IUserLimitRepository userLimitRepository, ILocalizationRepository localizationRepository) : ICommandHandler<DeleteCommnad, virtual Task>
    {
        public async Task<virtual Task> HandleAsync(DeleteCommnad request, CancellationToken cancellationToken = default)
        {
        var userLimit =
                await userLimitRepository.GetById(userLimitId)
                ?? throw new O24OpenAPIException(
                    await localizationRepository.GetResource("Admin.UserLimit.Value.NotFound")
                );
            await userLimitRepository.Delete(userLimit);
        }
    }
}
