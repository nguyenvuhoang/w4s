using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.ChannelAggregate;

namespace O24OpenAPI.CTH.API.Features.Channel
{
    public class GetChannelsWithWeeklyCommnad: BaseTransactionModel, ICommand<List<ChannelVm>>
    {

    }

    public class GetChannelsWithWeeklyHandler(IChannelScheduleRepository channelScheduleRepository, IChannelRepository channelRepository, IChannelScheduleIntervalRepository channelScheduleIntervalRepository) : ICommandHandler<GetChannelsWithWeeklyCommnad, List<ChannelVm>>
    {
        public async Task<List<ChannelVm>> HandleAsync(GetChannelsWithWeeklyCommnad request, CancellationToken cancellationToken = default)
        {
        var channels = await channelRepository.Table
                .OrderBy(c => c.SortOrder)
                .ThenBy(c => c.ChannelId)
                .Select(c => new ChannelVm
                {
                    Id = c.Id,
                    ChannelId = c.ChannelId,
                    ChannelName = c.ChannelName,
                    Description = c.Description,
                    Status = c.Status,
                    IsAlwaysOpen = c.IsAlwaysOpen,
                    TimeZoneId = c.TimeZoneId
                })
                .ToListAsync(ct);

            if (channels.Count == 0)
            {
                return channels;
            }

            var channelIds = channels.Select(x => x.Id).ToArray();

            if (channelScheduleRepository?.Table == null)
            {
                return [];
            }
            // lấy schedule trong tuần cho các channel
            var schedules = await channelScheduleRepository.Table
                .Where(s => channelIds.Contains(s.ChannelIdRef))
                .Select(s => new
                {
                    s.Id,
                    s.ChannelIdRef,
                    s.DayOfWeek,
                    s.IsClosed
                })
                .ToListAsync(ct);

            if (schedules.Count == 0)
            {
                return channels;
            }

            var scheduleIds = schedules.Select(x => x.Id).ToArray();

            // lấy intervals
            var intervals = await channelScheduleIntervalRepository.Table
             .Where(iv => scheduleIds.Contains(iv.ChannelScheduleIdRef))
             .OrderBy(iv => iv.SortOrder)
             .Select(iv => new
             {
                 iv.ChannelScheduleIdRef,
                 iv.StartTime,
                 iv.EndTime,
                 iv.SortOrder
             })
             .ToListAsync(ct);

            var result = intervals.Select(iv => new
            {
                iv.ChannelScheduleIdRef,
                StartTime = TimeOnly.FromTimeSpan(iv.StartTime).ToString("HH:mm"),
                EndTime = TimeOnly.FromTimeSpan(iv.EndTime).ToString("HH:mm"),
                iv.SortOrder
            }).ToList();

            // group intervals theo scheduleId
            var intervalsBySchedule = intervals
                .GroupBy(x => x.ChannelScheduleIdRef)
                .ToDictionary(g => g.Key, g => g.ToList());

            // group schedules theo channelId
            var schedulesByChannel = schedules
                .GroupBy(s => s.ChannelIdRef)
                .ToDictionary(g => g.Key, g => g.ToList());

            static int NormalizeDow(DayOfWeek d) => ((int)d + 6) % 7;

            foreach (var ch in channels)
            {
                if (!schedulesByChannel.TryGetValue(ch.Id, out var scList) || scList == null)
                {
                    ch.Weekly = EnsureSevenDays(new List<ChannelDayVm>());
                    continue;
                }

                var weekly = scList
                    .OrderBy(s => NormalizeDow(s.DayOfWeek)) // Thứ 2 -> CN
                    .Select(s =>
                    {
                        var day = new ChannelDayVm
                        {
                            DayOfWeek = (int)s.DayOfWeek,
                            DayName = DayName(s.DayOfWeek),
                            IsClosed = s.IsClosed
                        };

                        if (!s.IsClosed && intervalsBySchedule.TryGetValue(s.Id, out var ivs) && ivs != null)
                        {
                            var ordered = ivs.OrderBy(iv => iv.SortOrder)
                                             .ThenBy(iv => iv.StartTime);

                            foreach (var iv in ordered)
                            {
                                day.Intervals.Add(new ChannelIntervalVm
                                {
                                    Start = iv.StartTime.ToString(@"hh\:mm"),
                                    End = iv.EndTime.ToString(@"hh\:mm")
                                });
                            }
                        }

                        return day;
                    })
                    .ToList();

                weekly = EnsureSevenDays(weekly);

                ch.Weekly = weekly;

                var tz = TimeZoneInfo.FindSystemTimeZoneById(ch.TimeZoneId);
                var localNow = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, tz);

                var todayIndex = (int)localNow.DayOfWeek;

                foreach (var d in weekly)
                {
                    d.IsToday = d.DayOfWeek == todayIndex;
                }

                bool openNow = ch.IsAlwaysOpen;
                if (!openNow)
                {

                    var today = weekly.First(w => w.DayOfWeek == todayIndex);
                    if (!today.IsClosed && today.Intervals.Count > 0)
                    {
                        var nowT = TimeOnly.FromDateTime(localNow.DateTime);
                        openNow = today.Intervals.Any(iv =>
                        {
                            var start = TimeOnly.Parse(iv.Start);
                            var end = TimeOnly.Parse(iv.End);
                            return end > start ? (nowT >= start && nowT <= end) : (nowT >= start || nowT <= end);
                        });
                    }
                }
                ch.IsOpenNow = openNow;
            }

            return channels;
        }
    }
}
