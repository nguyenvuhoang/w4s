using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.ChannelAggregate;

namespace O24OpenAPI.CTH.API.Features.Channel
{
    public class CanLoginCommnad: BaseTransactionModel, ICommand<bool>
    {

    }

    public class CanLoginHandler(IChannelScheduleRepository channelScheduleRepository, IChannelRepository channelRepository, IChannelScheduleIntervalRepository channelScheduleIntervalRepository, IChannelUserOverrideRepository channelUserOverrideRepository) : ICommandHandler<CanLoginCommnad, bool>
    {
        public async Task<bool> HandleAsync(CanLoginCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrWhiteSpace(channelId))
            {
                throw new ArgumentException(nameof(channelId));
            }

            if (string.IsNullOrWhiteSpace(userId))
            {
                throw new ArgumentException(nameof(userId));
            }

            var cacheKey = new CacheKey($"channel:canlogin:{channelId}:{userId}");
            var cached = await _staticCacheManager.Get<bool?>(cacheKey);
            if (cached.HasValue)
            {
                return cached.Value;
            }

            var channel = await channelRepository.Table.FirstOrDefaultAsync(c => c.ChannelId == channelId, ct)
                         ?? throw new O24OpenAPIException($"Channel '{channelId}' not found.");

            var tz = TimeZoneInfo.FindSystemTimeZoneById(channel.TimeZoneId);
            var localNow = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, tz);
            var nowDate = localNow.DateTime.Date;
            var nowTime = localNow.TimeOfDay;
            var todayIdx = (int)localNow.DayOfWeek;

            if (!channel.Status)
            {
                var ov = await channelUserOverrideRepository.Table
                    .Where(x => x.ChannelIdRef == channel.Id && x.UserId == userId
                        && (!x.EffectiveFrom.HasValue || x.EffectiveFrom.Value.Date <= nowDate)
                        && (!x.EffectiveTo.HasValue || nowDate <= x.EffectiveTo.Value.Date)
                        && x.AllowWhenDisabled)
                    .FirstOrDefaultAsync(ct);

                if (ov == null)
                {
                    await _staticCacheManager.Set(cacheKey, false);
                    return false;
                }

                bool ok = ov.IsAllowedAllDay || await IsInUserOverrideIntervalsAsync(ov.Id, nowTime, ct);
                await _staticCacheManager.Set(cacheKey, ok);
                return ok;
            }

            if (channel.IsAlwaysOpen)
            {
                await _staticCacheManager.Set(cacheKey, true);
                return true;
            }
            var todayEnum = (DayOfWeek)todayIdx;

            var schedule = await channelScheduleRepository.Table
                .FirstOrDefaultAsync(s => s.ChannelIdRef == channel.Id && s.DayOfWeek == todayEnum, ct);

            bool openBySchedule = false;
            if (schedule is not null && !schedule.IsClosed)
            {
                var intervals = await channelScheduleIntervalRepository.Table
                    .Where(iv => iv.ChannelScheduleIdRef == schedule.Id)
                    .ToListAsync(ct);

                openBySchedule = intervals.Any(iv =>
                {
                    var start = iv.StartTime;
                    var end = iv.EndTime;
                    return end > start ? (nowTime >= start && nowTime <= end)
                                       : (nowTime >= start || nowTime <= end);
                });
            }

            if (openBySchedule)
            {
                await _staticCacheManager.Set(cacheKey, true);
                return true;
            }

            var userOv = await channelUserOverrideRepository.Table
                .Where(x => x.ChannelIdRef == channel.Id && x.UserId == userId
                    && (!x.EffectiveFrom.HasValue || x.EffectiveFrom.Value.Date <= nowDate)
                    && (!x.EffectiveTo.HasValue || nowDate <= x.EffectiveTo.Value.Date))
                .FirstOrDefaultAsync(ct);

            if (userOv == null)
            {
                await _staticCacheManager.Set(cacheKey, false);
                return false;
            }

            bool allowed = userOv.IsAllowedAllDay || await IsInUserOverrideIntervalsAsync(userOv.Id, nowTime, ct);
            await _staticCacheManager.Set(cacheKey, allowed);
            return allowed;
        }
    }
}
