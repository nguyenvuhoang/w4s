using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.ChannelAggregate;

namespace O24OpenAPI.CTH.API.Features.Channel
{
    public class IsChannelActiveCommnad: BaseTransactionModel, ICommand<bool>
    {

    }

    public class IsChannelActiveHandler(IChannelScheduleRepository channelScheduleRepository, IChannelRepository channelRepository, IChannelScheduleIntervalRepository channelScheduleIntervalRepository) : ICommandHandler<IsChannelActiveCommnad, bool>
    {
        public async Task<bool> HandleAsync(IsChannelActiveCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrWhiteSpace(channelId))
            {
                throw new ArgumentException("ChannelId is required", nameof(channelId));
            }

            var channel = await channelRepository.Table
                .FirstOrDefaultAsync(c => c.ChannelId == channelId, ct)
                ?? throw new O24OpenAPIException(
                    ChannelErrorCodes.ChannelNotFound,
                    $"Channel '{channelId}' not found."
                );

            if (!channel.Status)
            {
                throw new O24OpenAPIException(
                    ChannelErrorCodes.ChannelDisabled,
                    $"The Channel have been closed now. Please login in next time"
                );
            }

            if (channel.IsAlwaysOpen)
            {
                return true;
            }

            TimeZoneInfo tz;
            try
            {
                tz = TimeZoneInfo.FindSystemTimeZoneById(channel.TimeZoneId);
            }
            catch
            {
                throw new O24OpenAPIException(
                    ChannelErrorCodes.InvalidTimezone,
                    $"Invalid timezone '{channel.TimeZoneId}'."
                );
            }

            var localNow = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, tz);
            var todayEnum = localNow.DayOfWeek;
            var nowTime = localNow.TimeOfDay; // TimeSpan

            var schedule = await channelScheduleRepository.Table
                .FirstOrDefaultAsync(s => s.ChannelIdRef == channel.Id && s.DayOfWeek == todayEnum, ct);

            if (schedule == null || schedule.IsClosed)
            {
                throw new O24OpenAPIException(
                    ChannelErrorCodes.ScheduleClosedToday,
                    "Schedule working time is closed today."
                );
            }

            var intervals = await channelScheduleIntervalRepository.Table
                .Where(iv => iv.ChannelScheduleIdRef == schedule.Id)
                .ToListAsync(ct);

            if (intervals.Count == 0)
            {
                throw new O24OpenAPIException(
                    ChannelErrorCodes.NoIntervalsConfigured,
                    "No working intervals configured."
                );
            }

            var isOpenNow = intervals.Any(iv =>
            {
                var start = iv.StartTime;
                var end = iv.EndTime;

                if (end > start)
                {
                    return nowTime >= start && nowTime <= end;
                }
                else if (end < start)
                {
                    return nowTime >= start || nowTime <= end;
                }
                else
                {
                    return false;
                }
            });

            if (!isOpenNow)
            {
                throw new O24OpenAPIException(
                    ChannelErrorCodes.ClosedAtThisTime,
                    "Outside business hours."
                );
            }

            return true;
        }
    }
}
