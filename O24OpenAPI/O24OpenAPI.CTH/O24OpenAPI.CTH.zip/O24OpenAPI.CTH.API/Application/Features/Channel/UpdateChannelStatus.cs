using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.ChannelAggregate;

namespace O24OpenAPI.CTH.API.Features.Channel
{
    public class UpdateChannelStatusCommnad: BaseTransactionModel, ICommand<ChannelVm>
    {

    }

    public class UpdateChannelStatusHandler(IChannelRepository channelRepository) : ICommandHandler<UpdateChannelStatusCommnad, ChannelVm>
    {
        public async Task<ChannelVm> HandleAsync(UpdateChannelStatusCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrWhiteSpace(channelId))
            {
                throw new ArgumentException("channelId is required", nameof(channelId));
            }

            var channel = await channelRepository.Table
                .FirstOrDefaultAsync(c => c.ChannelId == channelId, ct)
                ?? throw new InvalidOperationException($"Channel '{channelId}' not found.");

            if (channel.Status == isOpen)
            {
                await InvalidateChannelActiveCacheAsync(channelId);

                var existed = await GetChannelByCodeAsync(channelId, ct);
                if (existed is not null)
                {
                    return existed;
                }

                return new ChannelVm
                {
                    Id = channel.Id,
                    ChannelId = channel.ChannelId,
                    ChannelName = channel.ChannelName,
                    Description = channel.Description,
                    Status = channel.Status,
                    IsAlwaysOpen = channel.IsAlwaysOpen,
                    TimeZoneId = channel.TimeZoneId,
                    Weekly = []
                };
            }

            channel.Status = isOpen;
            await channelRepository.Update(channel);

            await InvalidateChannelActiveCacheAsync(channelId);

            var updated = await GetChannelByCodeAsync(channelId, ct);
            if (updated is null)
            {
                return new ChannelVm
                {
                    Id = channel.Id,
                    ChannelId = channel.ChannelId,
                    ChannelName = channel.ChannelName,
                    Description = channel.Description,
                    Status = channel.Status,
                    IsAlwaysOpen = channel.IsAlwaysOpen,
                    TimeZoneId = channel.TimeZoneId,
                    Weekly = []
                };
            }

            return updated;
        }
    }
}
