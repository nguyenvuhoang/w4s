using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class GetCurrentCalendarCommnad: BaseTransactionModel, ICommand<virtual Task<Calendar>>
    {

    }

    public class GetCurrentCalendarHandler(ICalendarRepository calendarRepository, IBankRepository bankRepository) : ICommandHandler<GetCurrentCalendarCommnad, virtual Task<Calendar>>
    {
        public async Task<virtual Task<Calendar>> HandleAsync(GetCurrentCalendarCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrEmpty(currencyCode))
            {
                currencyCode = _adminSetting.BaseCurrency;
            }

            var query = calendarRepository.Table;
            query = query.Where(c => c.IsCurrentDate == 1 && c.CurrencyCode == currencyCode);

            var calendar = await query.FirstOrDefaultAsync();
            return await CreateIfNotExists(calendar, bankRepository.GetWorkingDate().Date, currencyCode);
        }
    }
}
