using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class ChangeWorkingDateCommnad: BaseTransactionModel, ICommand<virtual Task>
    {

    }

    public class ChangeWorkingDateHandler(IBankRepository bankRepository) : ICommandHandler<ChangeWorkingDateCommnad, virtual Task>
    {
        public async Task<virtual Task> HandleAsync(ChangeWorkingDateCommnad request, CancellationToken cancellationToken = default)
        {
        try
            {
                await bankRepository.UpdateWorkingDateTripletAsync(workingDate);
            }
            catch (Exception ex)
            {
                await ex.LogErrorAsync(ex.Message);
            }
        }
    }
}
