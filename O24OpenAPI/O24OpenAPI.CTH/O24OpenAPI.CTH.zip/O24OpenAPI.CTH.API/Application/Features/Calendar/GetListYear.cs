using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class GetListYearCommnad: BaseTransactionModel, ICommand<virtual Task<IPagedList<GetListYearResponseModel>>>
    {

    }

    public class GetListYearHandler(ICalendarRepository calendarRepository) : ICommandHandler<GetListYearCommnad, virtual Task<IPagedList<GetListYearResponseModel>>>
    {
        public async Task<virtual Task<IPagedList<GetListYearResponseModel>>> HandleAsync(GetListYearCommnad request, CancellationToken cancellationToken = default)
        {
        model.PageSize = (model.PageSize == 0) ? int.MaxValue : model.PageSize;
            var listYear = await (
                from calendar in calendarRepository.Table
                select new GetListYearResponseModel() { Caption = calendar.SqnDate.Year }
            )
                .Distinct()
                .ToPagedList(model.PageIndex, model.PageSize);
            return listYear;
        }
    }
}
