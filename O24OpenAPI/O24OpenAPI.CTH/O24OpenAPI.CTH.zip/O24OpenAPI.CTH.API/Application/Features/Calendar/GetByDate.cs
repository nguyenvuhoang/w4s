using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class GetByDateCommnad: BaseTransactionModel, ICommand<virtual Task<Calendar>>
    {

    }

    public class GetByDateHandler(ICalendarRepository calendarRepository) : ICommandHandler<GetByDateCommnad, virtual Task<Calendar>>
    {
        public async Task<virtual Task<Calendar>> HandleAsync(GetByDateCommnad request, CancellationToken cancellationToken = default)
        {
        return await calendarRepository
                .Table.Where(c => c.SqnDate.Date == date.Date)
                .FirstOrDefaultAsync();
        }
    }
}
