using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class CreditMaturityDateCommnad: BaseTransactionModel, ICommand<virtual Task<DateTime>>
    {

    }

    public class CreditMaturityDateHandler(ICalendarRepository calendarRepository) : ICommandHandler<CreditMaturityDateCommnad, virtual Task<DateTime>>
    {
        public async Task<virtual Task<DateTime>> HandleAsync(CreditMaturityDateCommnad request, CancellationToken cancellationToken = default)
        {
        if (holidayMoveOn == 0)
            {
                return date;
            }

            var returnDay = date;
            var query = await calendarRepository.Table.Where(c => c.SqnDate == date).ToListAsync();
            var count = query.Count;
            if (count == 0)
            {
                if (returnDay == toDate)
                {
                    if (returnDay == toDate)
                    {
                        returnDay = returnDay.AddDays(1);
                        while (
                            returnDay.DayOfWeek == DayOfWeek.Saturday
                            || returnDay.DayOfWeek == DayOfWeek.Sunday
                        )
                        {
                            returnDay = returnDay.AddDays(-1);
                        }
                    }
                }
                else
                {
                    if (holidayMoveOn < 0)
                    {
                        while (
                            returnDay.DayOfWeek == DayOfWeek.Saturday
                            || returnDay.DayOfWeek == DayOfWeek.Sunday
                        )
                        {
                            returnDay = returnDay.AddDays(-1);
                        }
                    }
                    else if (holidayMoveOn > 0)
                    {
                        while (
                            returnDay.DayOfWeek == DayOfWeek.Saturday
                            || returnDay.DayOfWeek == DayOfWeek.Sunday
                        )
                        {
                            returnDay = returnDay.AddDays(1);
                        }
                        if (returnDay == toDate)
                        {
                            returnDay = returnDay.AddDays(-1);
                            while (
                                returnDay.DayOfWeek == DayOfWeek.Saturday
                                || returnDay.DayOfWeek == DayOfWeek.Sunday
                            )
                            {
                                returnDay = returnDay.AddDays(-1);
                            }
                        }
                    }
                }
            }
            else
            {
                var query2 = await calendarRepository
                    .Table.Where(c => c.IsHoliday == 0 && c.SqnDate <= date)
                    .ToListAsync();
                if (date == toDate)
                {
                    returnDay = (
                        await calendarRepository
                            .Table.Where(c => c.IsHoliday == 0 && c.SqnDate <= date)
                            .Select(c => c.SqnDate)
                            .ToListAsync()
                    ).Max();
                }
                else
                {
                    if (holidayMoveOn < 0)
                    {
                        returnDay = (
                            await calendarRepository
                                .Table.Where(c => c.IsHoliday == 0 && c.SqnDate <= date)
                                .Select(c => c.SqnDate)
                                .ToListAsync()
                        ).Max();
                    }
                    else if (holidayMoveOn > 0)
                    {
                        returnDay = (
                            await calendarRepository
                                .Table.Where(c => c.IsHoliday == 0 && c.SqnDate >= date)
                                .Select(c => c.SqnDate)
                                .ToListAsync()
                        ).Min();
                    }
                }
            }
            return returnDay;
        }
    }
}
