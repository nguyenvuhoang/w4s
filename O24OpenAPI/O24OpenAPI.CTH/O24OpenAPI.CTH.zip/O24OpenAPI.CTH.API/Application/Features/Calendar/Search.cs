using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class SearchCommnad: BaseTransactionModel, ICommand<virtual Task<IPagedList<Calendar>>>
    {

    }

    public class SearchHandler(ICalendarRepository calendarRepository) : ICommandHandler<SearchCommnad, virtual Task<IPagedList<Calendar>>>
    {
        public async Task<virtual Task<IPagedList<Calendar>>> HandleAsync(SearchCommnad request, CancellationToken cancellationToken = default)
        {
        model.PageSize = model.PageSize == 0 ? int.MaxValue : model.PageSize;
            var calendars = await calendarRepository.GetAllPaged(
                query =>
                {
                    query = query.OrderBy(a => a.Id);
                    return query;
                },
                model.PageIndex,
                model.PageSize
            );
            return calendars;
        }
    }
}
