using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Models;
using O24OpenAPI.CTH.Models.Roles;
using O24OpenAPI.CTH.Models.User;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class SearchCommnad: BaseTransactionModel, ICommand<virtual Task<IPagedList<Calendar>>>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? Year { get; set; }
        public int? Month { get; set; }
    }

    public class SearchHandler(ICalendarRepository calendarRepository) : ICommandHandler<SearchCommnad, virtual Task<IPagedList<Calendar>>>
    {
        public async Task<virtual Task<IPagedList<Calendar>>> HandleAsync(SearchCommnad request, CancellationToken cancellationToken = default)
        {
        request.PageSize = request.PageSize == 0 ? int.MaxValue : request.PageSize;
            var calendars = await calendarRepository.GetAllPaged(
                query =>
                {
                    if (request.Year != null)
                    {
                        query = query.Where(a =>
                            a.SqnDate.Year.ToString().Contains(request.Year.ToString())
                        );
                    }
                    if (request.Month != null)
                    {
                        query = query.Where(a =>
                            a.SqnDate.Month.ToString().Contains(request.Month.ToString())
                        );
                    }
                    query = query.OrderBy(a => a.Id);
                    return query;
                },
                request.PageIndex,
                request.PageSize
            );
            return calendars;
        }
    }
}
