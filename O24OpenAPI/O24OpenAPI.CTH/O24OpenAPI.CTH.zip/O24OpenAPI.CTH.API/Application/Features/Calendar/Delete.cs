using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;
using O24OpenAPI.CTH.Domain.AggregatesModel.UserAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class DeleteCommnad: BaseTransactionModel, ICommand<virtual Task>
    {

    }

    public class DeleteHandler(ICalendarRepository calendarRepository, ILocalizationRepository localizationRepository) : ICommandHandler<DeleteCommnad, virtual Task>
    {
        public async Task<virtual Task> HandleAsync(DeleteCommnad request, CancellationToken cancellationToken = default)
        {
        var calendar = await GetById(calendarId);
            if (calendar == null)
            {
                throw new O24OpenAPIException(
                    await localizationRepository.GetResource("Admin.Calendar.Value.NotFound")
                );
            }

            await calendarRepository.Delete(calendar);
        }
    }
}
