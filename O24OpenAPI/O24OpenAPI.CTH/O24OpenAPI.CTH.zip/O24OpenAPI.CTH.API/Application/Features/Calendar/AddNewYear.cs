using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class AddNewYearCommnad: BaseTransactionModel, ICommand<IPagedList<Calendar>>
    {

    }

    public class AddNewYearHandler(ICalendarRepository calendarRepository) : ICommandHandler<AddNewYearCommnad, IPagedList<Calendar>>
    {
        public async Task<IPagedList<Calendar>> HandleAsync(AddNewYearCommnad request, CancellationToken cancellationToken = default)
        {
        var pageIndex = 0;
            var pageSize = Int32.MaxValue;
            var currencyCode = _adminSetting.BaseCurrency;

            if (year == 0)
            {
                year = DateTime
                    .ParseExact(
                        _adminSetting.Currdate,
                        "d/M/yyyy",
                        System.Globalization.CultureInfo.InvariantCulture
                    )
                    .Year;
            }

            var maxDate = new DateTime(year - 1, 12, 31);

            if (await calendarRepository.Table.AnyAsync())
            {
                maxDate = calendarRepository.Table.Max(c => c.SqnDate);
            }
            maxDate = maxDate.AddDays(1);

            var listCalendars = new List<Calendar>() { };
            do
            {
                var newCalendar = new Calendar();
                newCalendar.SqnDate = maxDate;
                newCalendar.CurrencyCode = currencyCode;
                if (maxDate.DayOfWeek == DayOfWeek.Saturday || maxDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    newCalendar.IsHoliday = 1;
                }

                if (maxDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    newCalendar.IsEndOfWeek = 1;
                }

                if (maxDate.AddDays(1).Day == 1)
                {
                    newCalendar.IsEndOfMonth = 1;
                }

                if (
                    maxDate.ToString("dd/MM") == "31/03"
                    || maxDate.ToString("dd/MM") == "30/06"
                    || maxDate.ToString("dd/MM") == "30/09"
                    || maxDate.ToString("dd/MM") == "31/12"
                )
                {
                    newCalendar.IsEndOfQuater = 1;
                }

                if (maxDate.ToString("dd/MM") == "30/06" || maxDate.ToString("dd/MM") == "31/12")
                {
                    newCalendar.IsEndOfHalfYear = 1;
                }

                if (maxDate.ToString("dd/MM") == "31/12")
                {
                    newCalendar.IsEndOfYear = 1;
                }

                if (maxDate.DayOfWeek == DayOfWeek.Monday)
                {
                    newCalendar.IsBeginOfWeek = 1;
                }

                if (maxDate.Day == 1)
                {
                    newCalendar.IsBeginOfMonth = 1;
                }

                if (
                    maxDate.AddDays(-1).ToString("dd/MM") == "31/03"
                    || maxDate.AddDays(-1).ToString("dd/MM") == "30/06"
                    || maxDate.AddDays(-1).ToString("dd/MM") == "30/09"
                    || maxDate.AddDays(-1).ToString("dd/MM") == "31/12"
                )
                {
                    newCalendar.IsBeginOfQuater = 1;
                }

                if (
                    maxDate.AddDays(-1).ToString("dd/MM") == "30/06"
                    || maxDate.AddDays(-1).ToString("dd/MM") == "31/12"
                )
                {
                    newCalendar.IsBeginOfHalfYear = 1;
                }

                if (maxDate.AddDays(-1).ToString("dd/MM") == "31/12")
                {
                    newCalendar.IsBeginOfYear = 1;
                }

                listCalendars.Add(newCalendar);
                maxDate = maxDate.AddDays(1);
            } while (maxDate.ToString("dd/MM") != "01/01");

            await Insert(listCalendars);
            var pagedListCalendars = await listCalendars.AsQueryable().ToPagedList(pageIndex, pageSize);
            return pagedListCalendars;
        }
    }
}
