using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class GetCalendarCommnad: BaseTransactionModel, ICommand<virtual Task<Calendar>>
    {

    }

    public class GetCalendarHandler(ICalendarRepository calendarRepository) : ICommandHandler<GetCalendarCommnad, virtual Task<Calendar>>
    {
        public async Task<virtual Task<Calendar>> HandleAsync(GetCalendarCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrEmpty(currencyCode))
            {
                currencyCode = _adminSetting.BaseCurrency;
            }

            var query = calendarRepository.Table;
            query = query.Where(c => c.SqnDate == date && c.CurrencyCode == currencyCode);

            var calendar = await query.FirstOrDefaultAsync();
            return await CreateIfNotExists(calendar, date, currencyCode);
        }
    }
}
