using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class GetSequenceDateByDaysCommnad: BaseTransactionModel, ICommand<virtual Task<Calendar>>
    {

    }

    public class GetSequenceDateByDaysHandler(ICalendarRepository calendarRepository) : ICommandHandler<GetSequenceDateByDaysCommnad, virtual Task<Calendar>>
    {
        public async Task<virtual Task<Calendar>> HandleAsync(GetSequenceDateByDaysCommnad request, CancellationToken cancellationToken = default)
        {
        DateTime busDate = ParamAdmin.GetBusDate();
            var calendar = await calendarRepository
                .Table.Where(c =>
                    (c.SqnDate.Date >= busDate.Date.AddDays(-365))
                    && (c.SqnDate.Date <= busDate.Date.AddDays(-days))
                    && c.IsHoliday == 0
                    && c.CurrencyCode == _adminSetting.BaseCurrency
                )
                .OrderByDescending(x => x.SqnDate)
                .FirstOrDefaultAsync();
            return calendar ?? new Calendar();
        }
    }
}
