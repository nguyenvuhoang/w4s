using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class GetNextCalendarCommnad: BaseTransactionModel, ICommand<virtual Task<Calendar>>
    {

    }

    public class GetNextCalendarHandler(ICalendarRepository calendarRepository) : ICommandHandler<GetNextCalendarCommnad, virtual Task<Calendar>>
    {
        public async Task<virtual Task<Calendar>> HandleAsync(GetNextCalendarCommnad request, CancellationToken cancellationToken = default)
        {
        if (string.IsNullOrEmpty(currencyCode))
            {
                currencyCode = _adminSetting.BaseCurrency;
            }

            //ensure calendar exist
            var c = await GetCalendar(date.AddDays(1).Date, currencyCode);

            var query = calendarRepository.Table;
            query = query.Where(c => c.SqnDate > date && c.CurrencyCode == currencyCode);
            query = query.OrderBy(c => c.SqnDate);

            var calendar = await query.FirstOrDefaultAsync();
            return await CreateIfNotExists(calendar, date.AddDays(1).Date, currencyCode);
        }
    }
}
