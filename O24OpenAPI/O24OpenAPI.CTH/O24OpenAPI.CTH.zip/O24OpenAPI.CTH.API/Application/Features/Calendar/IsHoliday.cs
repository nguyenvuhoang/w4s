using LinKit.Core.Cqrs;
using LinqToDB;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using O24OpenAPI.CTH.Constant;
using O24OpenAPI.CTH.Domain;
using O24OpenAPI.Framework.Models;
using O24OpenAPI.CTH.Domain.AggregatesModel.CalendarAggregate;

namespace O24OpenAPI.CTH.API.Features.Calendar
{
    public class IsHolidayCommnad: BaseTransactionModel, ICommand<bool>
    {

    }

    public class IsHolidayHandler(ICalendarRepository calendarRepository) : ICommandHandler<IsHolidayCommnad, bool>
    {
        public async Task<bool> HandleAsync(IsHolidayCommnad request, CancellationToken cancellationToken = default)
        {
        var cal = await calendarRepository
                .Table.Where(x => x.SqnDate.Date == date.Date && x.CurrencyCode == currencyCode)
                .FirstOrDefaultAsync();
            return Convert.ToBoolean(cal?.IsHoliday);
        }
    }
}
