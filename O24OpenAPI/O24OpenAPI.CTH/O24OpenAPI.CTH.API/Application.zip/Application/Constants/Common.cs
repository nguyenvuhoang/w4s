﻿namespace O24OpenAPI.CTH.Constant;

public partial class Common
{
    public const string NORMAL = "N";
    public const string BLOCK = "B";
    public const string ACTIVE = "A";
    public const string PENDINGFORDELETE = "G";
    public const string DELETED = "D";
}
