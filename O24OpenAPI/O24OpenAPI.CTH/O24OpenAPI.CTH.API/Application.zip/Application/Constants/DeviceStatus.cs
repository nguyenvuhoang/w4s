namespace O24OpenAPI.CTH.Constant;

public static class DeviceStatus
{
    public const string ACTIVE = "A";
    public const string INACTIVE = "I";
}
