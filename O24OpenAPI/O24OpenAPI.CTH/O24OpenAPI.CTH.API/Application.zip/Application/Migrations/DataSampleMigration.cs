﻿using O24OpenAPI.Data.Migrations;

namespace O24OpenAPI.CTH.API.Application.Migrations;

public class DataSampleMigration : BaseMigration
{
    public override void Up()
    {
        throw new NotImplementedException();
    }
}
