﻿using LinKit.Core.Abstractions;
using O24OpenAPI.CTH.API.Application.Abstractions;

namespace O24OpenAPI.CTH.API.Application.Services;

[RegisterService(Lifetime.Scoped)]
public class QdrantService : IQdrantService
{
}
